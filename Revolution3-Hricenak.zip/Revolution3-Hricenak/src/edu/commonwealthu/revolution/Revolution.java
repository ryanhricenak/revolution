package edu.commonwealthu.revolution;

import javafx.geometry.Point2D;

import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Back end for the game of Revolution. The game consists of a square grid of tiles
 * numbered 1-n. The goal is to put the tiles in ascending order through a series of
 * rotations of 2 x 2 subgrids, with the option of 3 x 3 subgrids.
 *
 * @author Ryan Hricenak
 */
public class Revolution {
    private int size;
    private static final int default_difficulty = 3;
    private int[][] grid;

    private boolean undid = true;
    private int numOfUndos = 0;
    public ArrayList<int[][]> undoHistory = new ArrayList<>();

    /**
     * Initializes a game of Revolution
     * @param newSize - determines the size of the game board
     * @param subGridSize - determines the size of the subgrids
     * @param difficulty - determines the number of rotations
     * @param isEasy - determines if the game is in easyMode
     */
    public Revolution(int newSize, int subGridSize, int difficulty, boolean isEasy){
        size = newSize;
        grid = new int[newSize][newSize];

        int tile = 1;
        for (int i = 0; i < newSize; i++) {
            for (int j = 0; j < newSize; j++) {
                grid[i][j] = tile++;
            }
        }

        // Make some random moves.
        if(isEasy){
            if(subGridSize == 3){
                for (int i = 0; i < difficulty; i++) {
                    randomTBTCounterclockwiseRotation(size);
                }
            } else{
                for (int i = 0; i < difficulty; i++) {
                    randomCounterClockwiseMove(size);
                }
            }
        } else {
            if(subGridSize == 3){
                for (int i = 0; i < difficulty; i++) {
                    randomMoveTBT(size);
                }
            }
            else{
                for (int i = 0; i < difficulty; i++) {
                    randomMove(size);
                }
            }
        }
        // Remove random moves from the history and add the current game state.
        undoHistory.clear();
        undoHistory.add(copyGrid());
    }

    /**
     * Initializes a game with n random rotations.
     */
    public Revolution(int n){
        // First put grid in winning configuration
        size = 3;
        int tile = 1;
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                grid[i][j] = tile++;
            }
        }

        // Make some random moves.
        for (int i = 0; i < n; i++) {
            randomMove(size);
        }

        // Remove random moves from the history and add the current game state.
        undoHistory.clear();
        undoHistory.add(copyGrid());
    }

    /**
     * Initializes the game to the default number of random rotations.
     */
    public Revolution(){
        this(default_difficulty);
    }


    /**
     * Used only by the constructor for initializing the game with random moves.
     */
    private void randomMove(int newSize){
        ThreadLocalRandom rand = ThreadLocalRandom.current();

        // Rotate the tile with the top-left corner at (r, c)
        int r = rand.nextInt(newSize - 1);
        int c = rand.nextInt(newSize - 1);
        int t1 = grid[r][c];

        if(rand.nextBoolean()){
            // clockwise
            int t2 = grid[r][c + 1];
            move(t1, t2);
        } else{
            //counterclockwise
            int t2 = grid[r + 1][c];
            move(t1, t2);
        }
    }

    /**
     * Performs a random counterclockwise rotation
     * Used for the easy mode shuffle
     */
    private void randomCounterClockwiseMove(int newSize){
        ThreadLocalRandom rand = ThreadLocalRandom.current();

        // Rotate the tile with the top-left corner at (r, c)
        int r = rand.nextInt(newSize - 1);
        int c = rand.nextInt(newSize - 1);
        int t1 = grid[r][c];
        int t2 = grid[r + 1][c];
        move(t1, t2);
    }

    /**
     * Random 3 x 3 move used to initialize the game with 3 x 3 subgrids
     */
    private void randomMoveTBT(int newSize){
        ThreadLocalRandom rand = ThreadLocalRandom.current();

        // Rotate the tile with the top-left corner at (r, c)
        int r = rand.nextInt(newSize - 2);
        int c = rand.nextInt(newSize - 2);
        int t1 = grid[r][c];

        if(rand.nextBoolean()){
            // clockwise
            int t2 = grid[r][c + 1];
            moveThreeByThree(t1, t2);
        } else{
            //counterclockwise
            int t2 = grid[r + 1][c];
            moveThreeByThree(t1, t2);
        }
    }

    /**
     * Rotates a 3 x 3 subgrid counterclockwise
     */
    private void randomTBTCounterclockwiseRotation(int newSize){
        ThreadLocalRandom rand = ThreadLocalRandom.current();

        // Rotate the tile with the top-left corner at (r, c)
        int r = rand.nextInt(newSize - 2);
        int c = rand.nextInt(newSize - 2);
        int t1 = grid[r][c];
        int t2 = grid[r + 1][c];
         moveThreeByThree(t1, t2);
    }

    /**
     * Makes a move in the game by rotating the 2 x 2 subgrid with anchor tile t1 in the
     * direction of t2.
     */
    public boolean move(int t1, int t2){
        // find t1
        for (int i = 0; i < size - 1; i++) {
            for (int j = 0; j < size - 1; j++) {
                if(grid[i][j] == t1){
                    // Check if t2 is to the right, if so perform a clockwise rotation.
                    if(grid[i][j + 1] == t2){


                        if(!undid) {
                            undoFix();
                        }


                        rotate(i, j);
                        undoHistory.add(copyGrid());
                        return true;
                    }
                    // Check if t2 is below, if so perform a counterclockwise rotation
                    if(grid[i + 1][j] == t2){
                        // Since a counterclockwise is equal to 3 clockwise, rotate
                        // the subgrid 3 times.

                        if(!undid) {
                            undoFix();
                        }

                        for (int k = 0; k < 3; k++) {
                            rotate(i, j);
                        }
                        undoHistory.add(copyGrid());
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**
     * Makes a clockwise move in the game by rotating the 2 x 2 subgrid with
     * anchor tile t1
     */
    public boolean move(int tile1){
        if(!undid){
            undoFix();
        }

        for (int i = 0; i < size - 1; i++) {
            for (int j = 0; j < size - 1; j++) {
                if(grid[i][j] == tile1){
                    rotate(i, j);
                    undoHistory.add(copyGrid());
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Performs a clockwise rotation of the 2 x 2 subgrid with anchor at (i, j). If (i, j)
     * is not valid, the method does nothing.
     */
    private void rotate(int i, int j){
        if(i >= 0 && i < size - 1 && j >=0 && j < size){
            int temp = grid[i][j];

            grid[i][j] = grid[i + 1][j];
            grid[i + 1][j] = grid[i + 1][j + 1];
            grid[i + 1][j + 1] = grid[i][j + 1];
            grid[i][j + 1] = temp;
        }
    }

    /**
     * Makes a move in the game by rotating the 3 x 3 subgrid with anchor tile t1 in the
     * direction of t2.
     */
    public boolean moveThreeByThree(int t1, int t2){
        // find t1
        for (int i = 0; i < size - 2; i++) {
            for (int j = 0; j < size - 2; j++) {
                if(grid[i][j] == t1){
                    // Check if t2 is to the right, if so perform a clockwise rotation.
                    if(grid[i][j + 1] == t2){

                        if(!undid) {
                            undoFix();
                        }

                        rotateThreeByThree(i, j);
                        undoHistory.add(copyGrid());
                        return true;
                    }
                    // Check if t2 is below, if so perform a counterclockwise rotation
                    if(grid[i + 1][j] == t2){
                        // Since a counterclockwise is equal to 3 clockwise, rotate
                        // the subgrid 3 times.

                        if(!undid) {
                            undoFix();
                        }

                        for (int k = 0; k < 7; k++) {
                            rotateThreeByThree(i, j);
                        }
                        undoHistory.add(copyGrid());
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**
     * Makes a clockwise move in the game by rotating the 3 x 3 subgrid with
     * anchor tile t1
     */

    public boolean easyMoveThreeByThree(int t1){
        if(!undid){
            undoFix();
            undid = true;
        }

        for (int i = 0; i < size - 2; i++) {
            for (int j = 0; j < size - 2; j++) {
                if(grid[i][j] == t1){
                    rotateThreeByThree(i, j);
                    undoHistory.add(copyGrid());
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Rotates the 3 x 3 subgrid anchored at t1 toward t2
     */
    private void rotateThreeByThree(int i, int j){
        if(i >= 0 && i < size - 1 && j >=0 && j < size){
            int temp = grid[i][j];

            grid[i][j] = grid[i + 1][j];
            grid[i + 1][j] = grid[i + 2][j];
            grid[i + 2][j] = grid[i + 2][j + 1];
            grid[i + 2][j + 1] = grid[i + 2][j + 2];
            grid[i + 2][j + 2] = grid[i + 1][j + 2];
            grid[i + 1][j + 2] = grid[i][j + 2];
            grid[i][j + 2] = grid[i][j + 1];
            grid[i][j + 1] = temp;
        }
    }

    /**
     * Returns a deep copy of the current grid.
     */
    private int[][] copyGrid(){
        int[][] copy = new int[size][size];
        for (int i = 0; i < size; i++) {
            System.arraycopy(grid[i], 0, copy[i], 0, size);
        }
        return copy;
    }

    public boolean isWinning(){
        int nextTile = 1;
        for(int[] row : grid){
            for (int tile : row) {
                if(tile != nextTile){
                    return false;
                }
                nextTile++;
            }
        }
        return true;
    }

    /**
     *  Undoes the most recent move made in the game. If the game history is empty, the
     *  method does nothing.
     */
    public boolean undo(){
        // I had tried to use the undo feature you presented in class, but if you make a
        // move after you undo, then undo again, then there would be some error that
        // would make it not do the last one

        if(undid){
            undid = false;
        }

        if(undoHistory.size() - numOfUndos == 1){
            return false;
        } else{
            int[][] temp = undoHistory.get(undoHistory.size() - (numOfUndos + 2)).clone();

            for (int i = 0; i < size; i++) {
                for (int j = 0; j < size; j++) {
                    grid[i][j] = temp[i][j];
                }
            }
            numOfUndos++;
        }
        return true;
    }

    /**
     * Undoes the undo function.
     */
    public boolean redo() {
        if(undid || numOfUndos == 0){
        return false;
        } else{
            int[][] temp = undoHistory.get(undoHistory.size() - (numOfUndos)).clone();

            for (int i = 0; i < size; i++) {
                for (int j = 0; j < size; j++) {
                    grid[i][j] = temp[i][j];
                }
            }
            numOfUndos--;
            return true;
        }
    }

    /**
     * Corrects the undo history after a move is made following an undo/redo
     */
    private void undoFix(){
        for (int i = 0; i < numOfUndos; i++) {
            undoHistory.remove(undoHistory.size() - 1);
        }
        numOfUndos = 0;
        undid = true;
    }


    /**
     * Returns the value of the tile at row i, col j
     */
    public int tileAt(int i, int j){
        return grid[i][j];
    }

    /**
     * Returns the index i, j of tile a
     */
    public Point2D indexOf(int a){
        for (int i = 0; i < grid.length - 1; i++) {
            for (int j = 0; j < grid.length - 1; j++) {
                if(grid[i][j] == a){
                    return new Point2D(i, j);
                }
            }
        }
        return new Point2D(-1, -1);
    }

    @Override
    public String toString() {
        String str = "";
        for (int[] row : grid) {
            for (int tile : row) {
                str += String.format("%3d ", tile);
            }
            str += "\n";
        }
        return str;
    }
}