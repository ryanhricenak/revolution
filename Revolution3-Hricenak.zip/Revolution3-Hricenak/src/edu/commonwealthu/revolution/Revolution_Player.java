package edu.commonwealthu.revolution;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.media.AudioClip;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

/**
 * A GUI front end for the game of Revolution.
 *
 * @author Ryan Hricenak
 */
public class Revolution_Player extends Application {

    private int gameGridSize = 1;
    private int subGridSize = 0;
    private int difficulty = 2;
    private boolean isEasyMode = false;

    private Revolution game;
    private Button[][] buttons;
    private int buttonSize = 0;

    private boolean isSecond = false;
    public int tile1 = 0;
    public int tile2 = 0;

    private int turnCount = 0;
    private final Label gameInfo = new Label("TOTAL MOVES: " + turnCount);

    private final int width = 350;
    private final int height = 500;
    private final Pane root = new Pane();
    private final Scene scene = new Scene(root, width, height, Color.BLACK);

    @Override
    public void start(Stage stage) {
        startMenu();
        stage.setTitle("Revolution");
        stage.setAlwaysOnTop(false);
        stage.setResizable(true);
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Adds the buttons to the game
     */
    private void setGame() {
        // Create a Vbox to hold all objects of the game
        VBox userInterface = new VBox(22);
        userInterface.setPadding(new Insets(15));
        userInterface.setAlignment(Pos.CENTER);

        String rootColor = "-fx-background-color: #B2B3AE;";
        root.setStyle(rootColor);

        //Arrange buttons in a grid pane
        GridPane gridPane = new GridPane();
        gridPane.setStyle("-fx-background-color: BLACK;");
        gridPane.setMaxSize(300, 300);
        final int hvGap = 30 - (5 * gameGridSize);
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setHgap(hvGap);
        gridPane.setVgap(hvGap);
        userInterface.getChildren().add(gridPane);

        buttons = new Button[gameGridSize][gameGridSize];

        // Create the buttons, style them, and register event handlers.
        final int fontSize = 24;
        buttonSize = 280 / gameGridSize;

        Font font = Font.font("Monotype", FontWeight.BOLD, fontSize);
        String buttonStyle = "-fx-border-color: DARKSLATEGRAY; -fx-border-width: 2;";

        for (int i = 0; i < buttons.length; i++) {
            for (int j = 0; j < buttons[i].length; j++) {
                buttons[i][j] = new Button();
                buttons[i][j].setMaxSize(buttonSize, buttonSize);
                buttons[i][j].setStyle(buttonStyle);
                buttons[i][j].setPadding(new Insets(-1));
                buttons[i][j].setFont(font);
                buttons[i][j].setPrefSize(buttonSize, buttonSize);
                gridPane.add(buttons[i][j], j, i);
            }
        }
        setButtonHandler();

        // Create the HBox that contains the undo, redo, and pause buttons
        HBox widgetBox = getWidgetBox();
        userInterface.getChildren().add(widgetBox);

        // Create the labale containing the game information
        VBox labelBox = getLabelBox();
        userInterface.getChildren().add(labelBox);
        root.getChildren().add(userInterface);

        setButtonText();
    }

    /**
     * Sets the appropriayte buttonHandler depending on the game mode
     */
    private void setButtonHandler(){
        class ButtonHandler implements EventHandler<ActionEvent> {
            @Override
            public void handle(ActionEvent actionEvent) {
                Button button = (Button) actionEvent.getSource();
                boolean success;

                if (tile1 == Integer.parseInt(button.getText())) {
                    // the user clicked the first tile again, so accept it again as tile 1
                    tile1 = Integer.parseInt(button.getText());
                } else {
                    if (isSecond) {
                        // the user has chosen the second tile
                        tile2 = Integer.parseInt(button.getText());
                        isSecond = false;

                        success = game.move(tile1, tile2);
                        rotate(tile1, tile2);
                        if (success) {
                            // the move is successful, increase the turn count
                            turnCount++;
                            if (turnCount > 99) {
                                gameInfo.setText("TOTAL MOVES: 99+");
                            } else {
                                gameInfo.setText("TOTAL MOVES: " + turnCount);
                            }
                        } else {
                            // the move is unsuccessful
                            gameInfo.setText("INVALID MOVE");
                        }

                        // reset the tiles and repaint the tiles
                        tile1 = 0;
                        tile2 = 0;
                        setButtonText();
                    } else {
                        // the user has chosen the first tile
                        tile1 = Integer.parseInt(button.getText());
                        isSecond = !isSecond;
                    }
                }
                if (game.isWinning()) {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("GAME OVER");
                    alert.setHeaderText("You have solved the puzzle!");
                    alert.setContentText("Goodbye.");
                    alert.showAndWait();
                    System.exit(0);
                }
            }
        }

        class ThreeByThreeButtonHandler implements EventHandler<ActionEvent>{
            @Override
            public void handle(ActionEvent actionEvent){
                Button button = (Button) actionEvent.getSource();
                boolean success;

                if (tile1 == Integer.parseInt(button.getText())) {
                    tile1 = Integer.parseInt(button.getText());
                } else {
                    if (isSecond) {
                        tile2 = Integer.parseInt(button.getText());
                        isSecond = false;

                        success = game.moveThreeByThree(tile1, tile2);
                        rotate(tile1, tile2);
                        if (success) {
                            turnCount++;

                            System.out.println(game.undoHistory.size());

                            if (turnCount > 99) {
                                gameInfo.setText("TOTAL MOVES: 99+");
                            } else {
                                gameInfo.setText("TOTAL MOVES: " + turnCount);
                            }

                        } else {
                            gameInfo.setText("INVALID MOVE");
                        }
                        tile1 = 0;
                        tile2 = 0;
                        setButtonText();
                    } else {
                        tile1 = Integer.parseInt(button.getText());
                        isSecond = !isSecond;
                    }
                }
                if (game.isWinning()) {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("GAME OVER");
                    alert.setHeaderText("You have solved the puzzle!");
                    alert.setContentText("Goodbye.");
                    alert.showAndWait();
                    System.exit(0);
                }
            }
        }

        class EasyButtonHandler implements EventHandler<ActionEvent> {
            @Override
            public void handle(ActionEvent actionEvent) {
                Button button = (Button) actionEvent.getSource();
                boolean success;

                tile1 = Integer.parseInt(button.getText());

                success = game.move(tile1);
                rotate(tile1, tile2);

                if (success) {
                    turnCount++;
                    if (turnCount > 99) {
                        gameInfo.setText("TOTAL MOVES: 99+");
                    } else {
                        gameInfo.setText("TOTAL MOVES: " + turnCount);
                    }
                } else {
                    gameInfo.setText("INVALID MOVE");
                }
                tile1 = 0;
                tile2 = 0;
                setButtonText();

                if (game.isWinning()) {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("GAME OVER");
                    alert.setHeaderText("You have solved the puzzle!");
                    alert.setContentText("Goodbye.");
                    alert.showAndWait();
                    System.exit(0);
                }
            }
        }

        class EasyTBTButtonHandler implements EventHandler<ActionEvent>{
            @Override
            public void handle(ActionEvent actionEvent){
                Button button = (Button) actionEvent.getSource();
                boolean success;

                tile1 = Integer.parseInt(button.getText());

                success = game.easyMoveThreeByThree(tile1);

                if (success) {
                    rotate(tile1, tile2);
                    turnCount++;
                    if (turnCount > 99) {
                        gameInfo.setText("TOTAL MOVES: 99+");
                    } else {
                        gameInfo.setText("TOTAL MOVES: " + turnCount);
                    }
                } else {
                    gameInfo.setText("INVALID MOVE");
                }
                tile1 = 0;
                tile2 = 0;
                setButtonText();

                if (game.isWinning()) {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("GAME OVER");
                    alert.setHeaderText("You have solved the puzzle!");
                    alert.setContentText("Goodbye.");
                    alert.showAndWait();
                    System.exit(0);
                }
            }
        }

        ButtonHandler buttonHandler = new ButtonHandler();
        EasyButtonHandler easyButtonHandler = new EasyButtonHandler();
        ThreeByThreeButtonHandler tbtButtonHandler = new ThreeByThreeButtonHandler();
        EasyTBTButtonHandler easyTBTButtonHandler = new EasyTBTButtonHandler();

        for (int i = 0; i < gameGridSize; i++) {
            for (int j = 0; j < gameGridSize; j++) {
                if (!isEasyMode) {
                    if(subGridSize == 3){
                        buttons[i][j].setOnAction(tbtButtonHandler);
                    } else{
                        buttons[i][j].setOnAction(buttonHandler);
                    }
                }
                if (isEasyMode) {
                    if(subGridSize == 3){
                        buttons[i][j].setOnAction(easyTBTButtonHandler);
                    } else{
                        buttons[i][j].setOnAction(easyButtonHandler);
                    }
                }
            }
        }
    }

    /**
     * Returns the button widget box
     */
    private HBox getWidgetBox(){
        HBox widgetBox = new HBox(22);
        widgetBox.setAlignment(Pos.CENTER);

        String undoButtonStyle = "-fx-font-size: 20; -fx-font-weight: bold;"
                + "-fx-border-color: #363637;-fx-background-color: #848582;" +
                "-fx-font-color:white;-fx-border-width: 3;";

        Button undoButton = new Button("UNDO");
        Button pauseButton = new Button("||");
        Button redoButton = new Button("REDO");

        undoButton.setOnAction(e -> {
            boolean f = game.undo();
            if (!f) {
                gameInfo.setText("No Moves to Undo");
            }
            setButtonText();
            isSecond = false;
        });

        redoButton.setOnAction(e -> {
            boolean f = game.redo();
            if (!f) {
                gameInfo.setText("No Moves to Redo");
            } else{
                setButtonText();
            }
            setButtonText();
            isSecond = false;
        });

        pauseButton.setOnAction(e -> pauseMenu());

        undoButton.setStyle(undoButtonStyle);
        pauseButton.setStyle(undoButtonStyle);
        redoButton.setStyle(undoButtonStyle);

        //Create the label that holds the game information
        Font font1 = new Font("file:resources/digital-7 (italic)", 20);
        gameInfo.setFont(font1);

        widgetBox.getChildren().addAll(undoButton, pauseButton, redoButton);
        return widgetBox;
    }

    /**
     * Returns the label box
     */
    private VBox getLabelBox(){
        VBox labelBox = new VBox(10);
        String labelBoxStyle = "-fx-background-color: #023020;" +
                " -fx-border-color: #363637; -fx-border-width: 3";
        labelBox.setAlignment(Pos.CENTER);
        labelBox.setStyle(labelBoxStyle);
        labelBox.getChildren().add(gameInfo);

        Font labelFont = Font.loadFont("file:resources/digital-7 (italic).ttf", 28);
        gameInfo.setTextFill(new Color(0, 1, 0, 1));
        gameInfo.setFont(labelFont);
        return labelBox;
    }

    /**
     * Sets the text on each button to the corresponding tile number in the game.
     */
    private void setButtonText() {
        for (int i = 0; i < buttons.length; i++) {
            for (int j = 0; j < buttons[i].length; j++) {
                int tile = game.tileAt(i, j);
                buttons[i][j].setVisible(true);
                buttons[i][j].setMaxSize(buttonSize, buttonSize);
                String s = "-fx-border-color: #000000";
                buttons[i][j].setStyle(s);

                buttons[i][j].setShape(new Circle(buttonSize));
                buttons[i][j].setText(tile + "");
                buttons[i][j].setFont(new Font("Arial", 1));
                buttons[i][j].setTextAlignment(TextAlignment.LEFT);
                buttons[i][j].textOverrunProperty();

                String style = "-fx-background-color: null; -fx-border-color: null;";
                buttons[i][j].setGraphic(setButtonPic(tile));
                buttons[i][j].setStyle(style);
            }
        }
    }

    /**
     * Sets the background pictures for each button
     */
    private StackPane setButtonPic(int tile) {
        int a = tile;

        if (a > 9) {
            a = 10;
        }

        String[] planets = {" ", "mercury.png", "venus.png", "earth.png", "mars.png",
                "jupiter.png", "saturn.png", "uranus.png", "neptune.png", "pluto.png",
                "asteroid.png"};

        ImageView temp = new ImageView();
        Image image = new Image("file:resources/planets/" + planets[a]);
        temp.setImage(image);
        temp.setFitHeight(buttonSize);
        temp.setFitWidth(buttonSize);

        Font font = Font.font("Monotype", FontWeight.BOLD, 24);
        Label l = new Label(tile + "");
        l.setFont(font);

        StackPane tempPane = new StackPane();
        tempPane.getChildren().addAll(temp, l);

        return tempPane;
    }

    /**
     * PLays the sound effect for the rotation
     */
    private void rotate(int t1, int t2) {
        AudioClip whoosh = new AudioClip("file:resources/whoosh.mp3");
        whoosh.play();
    }

    /**
     * Creates and displays the start menu
     */
    private void startMenu() {
        // set up the VBox to act as the start menu
        VBox startMenu = new VBox(18);
        startMenu.setAlignment(Pos.CENTER);
        startMenu.setPadding(new Insets(40));

        String s = "-fx-background-color: #102030";
        startMenu.setStyle(s);
        root.setStyle(s);

        ImageView revolution = new ImageView(
                new Image("file:resources/revolution_title.png"));
        revolution.setFitHeight(50);
        revolution.setFitHeight(50);
        revolution.setFitWidth(280);
        startMenu.getChildren().add(revolution);

        // Set up the HBox for the game grid sizes
        HBox sizeHBox = new HBox(22);
        sizeHBox.setAlignment(Pos.CENTER);

        // Create the radio buttons
        RadioButton[] sizeButtons = new RadioButton[3];
        sizeButtons[0] = new RadioButton();
        sizeButtons[0].setSelected(true);
        sizeButtons[1] = new RadioButton();
        sizeButtons[2] = new RadioButton();
        ToggleGroup toggleGroup = new ToggleGroup();
        toggleGroup.getToggles().addAll(sizeButtons);

        // create the images for the game board size
        VBox[] sizeBoxes = new VBox[3];
        ImageView[] sizePics = {new ImageView(new Image("file:resources/3x3.png")),
                new ImageView(new Image("file:resources/4x4.png")),
                new ImageView(new Image("file:resources/5x5.png"))};
        Label[] sizeLabels = {new Label("Small"), new Label("Medium"),
                new Label("Large")};

        for (int i = 0; i < sizeBoxes.length; i++) {
            sizeBoxes[i] = new VBox();
            sizeBoxes[i].setAlignment(Pos.CENTER);
            sizePics[i].setFitHeight(75);
            sizePics[i].setFitWidth(75);
            sizeLabels[i].setTextFill(Color.WHITE);
            sizeBoxes[i].getChildren().addAll(sizePics[i], sizeLabels[i], sizeButtons[i]);
            sizeHBox.getChildren().add(sizeBoxes[i]);
        }
        startMenu.getChildren().add(sizeHBox);

        // Set up the HBox for the sub-grid sizes
        HBox subGridHBox = new HBox(22);
        subGridHBox.setAlignment(Pos.CENTER);

        RadioButton[] subGridButtons = new RadioButton[2];
        subGridButtons[0] = new RadioButton();
        subGridButtons[0].setSelected(true);
        subGridButtons[1] = new RadioButton();
        ToggleGroup subGridToggle = new ToggleGroup();
        subGridToggle.getToggles().addAll(subGridButtons);


        VBox[] subGridBoxes = new VBox[2];
        ImageView[] subGridPics = {new ImageView(new Image("2x2.png")),
                new ImageView(new Image("3x3Subgrid.png"))};
        Label[] subGridLabels = {new Label("2 x 2"), new Label("3 x 3")};

        for (int i = 0; i < subGridBoxes.length; i++) {
            subGridBoxes[i] = new VBox();
            subGridBoxes[i].setAlignment(Pos.CENTER);
            subGridPics[i].setFitWidth(75);
            subGridPics[i].setFitHeight(75);
            subGridLabels[i].setTextFill(Color.WHITE);
            subGridBoxes[i].getChildren().addAll(subGridPics[i], subGridLabels[i],
                    subGridButtons[i]);
            subGridHBox.getChildren().add(subGridBoxes[i]);
        }
        startMenu.getChildren().add(subGridHBox);

        // Create the difficulty slider with the help of a helper method
        Slider difficultySlider = getSlider();

        startMenu.getChildren().add(difficultySlider);

        // add Easy mode checkbox
        CheckBox easyMode = new CheckBox("Easy Mode");
        easyMode.setTextFill(Color.WHITE);
        easyMode.setAlignment(Pos.CENTER);
        startMenu.getChildren().add(easyMode);

        class StartButtonHandler implements EventHandler<ActionEvent> {
            @Override
            public void handle(ActionEvent actionEvent) {
                for (int i = 0; i < sizeButtons.length; i++) {
                    if (sizeButtons[i].isSelected()) {
                        gameGridSize = i + 3;
                    }
                }

                if (subGridButtons[0].isSelected()) {
                    subGridSize = 2;
                } else {
                    subGridSize = 3;
                }

                isEasyMode = easyMode.isSelected();

                difficulty = (int) difficultySlider.getValue();

                game = new Revolution(gameGridSize, subGridSize, difficulty, isEasyMode);
                turnCount = 0;
                gameInfo.setText("TOTAL MOVES: 0");

                root.getChildren().clear();
                setGame();
            }
        }
        StartButtonHandler startButtonHandler = new StartButtonHandler();

        // add start game button
        Button startGameButton = new Button("Start Game");
        startGameButton.setOnAction(startButtonHandler);
        startGameButton.setAlignment(Pos.CENTER);
        startMenu.getChildren().add(startGameButton);

        root.getChildren().add(startMenu);
    }

    /**
     * Creates the slider for the difficulty
     */
    private static Slider getSlider() {
        Slider slider = new Slider();
        slider.setBlockIncrement(1);
        slider.setMajorTickUnit(1);
        slider.setMinorTickCount(0);
        slider.setMin(1);
        slider.setMax(10);
        slider.setShowTickLabels(true);
        slider.setShowTickMarks(true);
        slider.setSnapToTicks(true);

        return slider;
    }

    /**
     * Creates and displays the pause menu
     */
    private void pauseMenu() {
        root.getChildren().clear();
        VBox pauseMenu = new VBox(22);

        Insets pauseInset = new Insets(70);
        pauseMenu.setPadding(pauseInset);

        pauseMenu.setAlignment(Pos.CENTER);

        Button resumeButton = new Button("RESUME");
        Button newGameButton = new Button("NEW GAME");

        String pauseStyle = "-fx-font-size: 28; -fx-font-weight: bold;"
                + "-fx-border-color: #363637;-fx-background-color: #848582;" +
                "-fx-font-color:white;-fx-border-width: 3;";
        resumeButton.setStyle(pauseStyle);
        newGameButton.setStyle(pauseStyle);

        resumeButton.setAlignment(Pos.CENTER);
        newGameButton.setAlignment(Pos.CENTER);

        resumeButton.setOnAction(e -> {
            root.getChildren().clear();
            isSecond = false;
            setGame();
        });
        newGameButton.setOnAction(e -> {
            root.getChildren().clear();
            isSecond = false;
            startMenu();
        });

        pauseMenu.setAlignment(Pos.CENTER);
        pauseMenu.getChildren().add(resumeButton);
        pauseMenu.getChildren().add(newGameButton);

        root.getChildren().add(pauseMenu);
    }

    public static void main(String[] args) {
        launch(args);
    }
}